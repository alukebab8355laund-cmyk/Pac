#!/data/data/com.termux/files/usr/bin/python3
"""🎨 PAC Core Compiler v1.0 — Pure Python, без зависимостей"""
import sys, os, struct, zlib

def png_chunk(ctype, data):
    return struct.pack('>I', len(data)) + ctype + data + struct.pack('>I', zlib.crc32(ctype + data) & 0xffffffff)

def parse_color(c):
    c = c.lstrip('#')
    if len(c) == 3:
        c = c[0]*2 + c[1]*2 + c[2]*2
    return tuple(int(c[i:i+2], 16) for i in (0, 2, 4)) + (255,)

def compile_pac(input_file, output_file="output.png"):
    with open(input_file) as f:
        lines = f.readlines()
    
    width, height = 100, 100
    bg = (0, 0, 0, 255)
    pixels = {}
    
    for line in lines:
        line = line.strip()
        if not line or line.startswith('//'): 
            continue
        
        parts = line.split()
        if not parts:
            continue
        cmd = parts[0]
        
        if cmd == '/size' and len(parts) >= 3:
            width, height = int(parts[1]), int(parts[2])
        elif cmd == '/bg' and len(parts) >= 2:
            bg = parse_color(parts[1])
        elif cmd == '/1px' and len(parts) >= 4:
            c = parse_color(parts[1])
            x, y = int(parts[2]), int(parts[3])
            pixels[(x, y)] = c
        elif cmd == '/rect' and len(parts) >= 6:
            c = parse_color(parts[1])
            x, y, w, h = int(parts[2]), int(parts[3]), int(parts[4]), int(parts[5])
            for dy in range(h):
                for dx in range(w):
                    pixels[(x+dx, y+dy)] = c
        elif cmd == '/save' and len(parts) >= 2:
            output_file = parts[1]

    # Генерация PNG
    signature = b'\x89PNG\r\n\x1a\n'
    ihdr = png_chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0))
    
    raw = b''
    for y in range(height):
        raw += b'\x00'  # фильтр None
        for x in range(width):
            raw += pixels.get((x, y), bg)
    
    idat = png_chunk(b'IDAT', zlib.compress(raw, 9))
    iend = png_chunk(b'IEND', b'')
    
    # Сохранение в Загрузки телефона
    out_path = os.path.expanduser(f"~/storage/downloads/{output_file}")
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    
    with open(out_path, 'wb') as f:
        f.write(signature + ihdr + idat + iend)
    
    print(f"✅ Сохранено в Загрузки: {output_file}")
    print(f"📏 Размер: {width}x{height} | Пикселей задано: {len(pixels)}")

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Использование: pac <файл.pac> [выход.png]")
        sys.exit(1)
    compile_pac(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else "output.png")
